module.exports = {
    apps: [
      {
        name: 'pizza-app',
        script: './src/server.js'
      }
    ]
  };